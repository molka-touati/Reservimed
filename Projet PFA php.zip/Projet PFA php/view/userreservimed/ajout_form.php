<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/form.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <title> Admin ReserviMed.tn || Ajouter User </title>
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>
<body>

  <section class="form-sec">

      <form method="post" action="index.php?controller=utilisateur&action=ajout2">
        <fieldset>
          <legend><h1><strong>Ajout d'un utilisateur</h1></strong> </legend> 
        <div>
          <label for="cin">NCIN :</label> 
          <input type="text"  name="cin"  id="cin" maxlength="8" required/>
          </div> 
        <div>
          <label for="nom">Nom :</label> 
          <input type="text"  name="nom" id="nom"  required/>
          </div> 
        <div>
          <label for="prenom">Prenom :</label> 
          <input type="text" name="prenom" id="prenom"  required/>
          </div> 
          <div>
          <label for="email">Email :</label> 
          <input type="email" name="email" id="email"  required/>
          </div> 
          <div>
          <label for="telephone">Téléphone :</label> 
          <input type="text" name="telephone" id="telephone"  required/>
          </div> 
          <div>
          <label for="date_naissance">Date de naissance :</label> 
          <input type="date" name="date_naissance" id="date_naissance"  required/>
          </div> 
          <div>
          <label for="p">Ville :</label> 
          <input type="text" name="ville" id="ville"  required/>
          </div> 
          <div>
          <label for="lieuDeVie">Gouvernaurat :</label> 
                          <select id="lieuDeVie" name="lieuDeVie" required>
                            <option value="">Choisir votre Gouvernaurat</option>
                            <option value="Ariana">Ariana</option>
                            <option value="Béja">Béja</option>
                            <option value="Ben Arous">Ben Arous</option>
                            <option value="Bizerte">Bizerte</option>
                            <option value="Gabès">Gabès</option>
                            <option value="Gafsa">Gafsa</option>
                            <option value="Jendouba">Jendouba</option>
                            <option value="Kairouan">Kairouan</option>
                            <option value="Kasserine">Kasserine</option>
                            <option value="Kébili">Kébili</option>
                            <option value="Mahdia">Mahdia</option>
                            <option value="Manouba">Manouba</option>
                            <option value="Médenine">Médenine</option>
                            <option value="Monastir">Monastir</option>
                            <option value="Nabeul">Nabeul</option>
                            <option value="Sfax">Sfax</option>
                            <option value="Sidi Bouzid">Sidi Bouzid</option>
                            <option value="Silana">Silana</option>
                            <option value="Sousse">Sousse</option>
                            <option value="Tataouine">Tataouine</option>
                            <option value="Tozeur">Tozeur</option>
                            <option value="Tunis">Tunis</option>
                            <option value="Zaghouan">Zaghouan</option>
                            </select>
                          </div>
                            <div>
                            <label for="password">Password :</label>
                            <input type="password" id="password" name="password" placeholder="Mot de passe" required>
                        </div>
                        
                          <div>
                          <label style="font-size: 20px;"for="genre">Genre : </label>
                          <input type="radio" id="genreM" name="genre" value="Masculin" required> <label for="genreM">Masculin</label>
                          <input type="radio" id="genreF" name="genre" value="Féminin" required><label for="genreF">Féminin</label>
                          </div> <br>
                          <div>
                        <input type="submit" value="Ajouter" /> 
          </div>
        </fieldset> 
      </form>
          </section>

<footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
      
    </footer>
     </body>
     </html>