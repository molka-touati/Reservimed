<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin ReserviMed.tn || Liste Users </title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Liste.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
</head>
<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>

<body>
<br><br>
<section>
   
        <h2 class="titre"><strong>Liste des Utilisateurs</strong></h2>

        <p>Nombre d'utilisateurs trouvés : <?= count($listeUtilisateurs) ?></p>
        <div>
          <a href="index.php?controller=utilisateur&action=ajout" class="btn btn-light btn-lg text-info " ><h6><strong>Ajouter un utilisateur</strong> </h6></a>
        </div>
        <br>
        
        <table >
        <thead>
          <tr>
            <th >Nom</th>
            <th >Prenom</th>
            <th >Mail</th>
            <th >CIN</th>
            <th >Num telephone</th>
            <th >Date de naissance </th>
            <th > Ville</th>
            <th >Gouvernaurat</th>
            <th >Genre </th>
            <th >Mot de passe </th>
            <th>Modifier ou supprimer</th>
        </tr>
       </thead>
       <tbody>
        <tr>
        <?php
        foreach($listeUtilisateurs as $utilisateur){
        ?>
            <td> <?= $utilisateur->nomUT ?></td>
            <td> <?= $utilisateur->prenomUT ?></td>
            <td> <?= $utilisateur->emailUT ?></td>
            <td><?= $utilisateur->CIN ?></td>
            <td> <?= $utilisateur->numtel ?></td>
            <td> <?= $utilisateur->ddn ?></td>
            <td><?= $utilisateur->villeUT ?></td>
            <td> <?= $utilisateur->gvrUT ?></td>
            <td> <?= $utilisateur->genre ?></td>
            <td><?= $utilisateur->mdp ?></td>
            <td>
              <div>
                <a href="index.php?controller=utilisateur&action=modif&cin=<?= $utilisateur->CIN ?>" class="btn btn-success text-light " ><h6><strong>Modifier</strong> </h6></a>
              
                <a href="index.php?controller=utilisateur&action=delete&cin=<?= $utilisateur->CIN ?>" class="btn btn-danger text-light " ><h6><strong>Supprimer</strong> </h6></a>
              </div>  
        </td>
        </tr>
        </tbody>
        <?php
        }
        ?>
</section>


</body>
</html>