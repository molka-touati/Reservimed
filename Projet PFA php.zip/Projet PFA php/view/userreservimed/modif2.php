<?php
if($resultat){
    echo "<p>Bravo! Modification avec succès.</p>";
}
else{
    echo "<p>Echec!</p>";
}
?>
<a href="index.php?controller=utilisateur&action=lister">Retour à la page d'accueil</a>