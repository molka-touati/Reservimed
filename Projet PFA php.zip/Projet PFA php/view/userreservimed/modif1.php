<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/form.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <title> Admin ReserviMed.tn || Modifier User </title>
    
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>

<body>


<section class="form-sec">
        <form action="index.php?controller=utilisateur&action=modif2" method="post">
          <legend><h1><strong>Modifier un utilisateur</h1></strong></legend>
        
           
            <div>
                <label for="CIN">CIN :</label>
                <input type="text" name="cin" id="cin" value="<?= $utilisateur->CIN ?>">
</div>
            <div>
                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" value="<?= $utilisateur->nomUT ?>">
</div>
            <div>
                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" value="<?= $utilisateur->prenomUT ?>">
</div>
            <div>
                <label for="email">Email :</label>
                <input type="email" name="email" id="email" value="<?= $utilisateur->emailUT ?>">
</div>
            <div>
                <label for="telephone">Téléphone :</label>
                <input type="text" name="telephone" id="telephone" value="<?= $utilisateur->numtel ?>">
</div>
            <div>
                <label for="date_naissance">Date de Naissance :</label>
                <input type="date" name="date_naissance" id="date_naissance" value="<?= $utilisateur->ddn ?>">
</div>
            <div>
                <label for="ville">Ville :</label>
                <input type="text" name="ville" id="ville" value="<?= $utilisateur->villeUT ?>">
</div>
            <div>
                <label for="lieuDeVie">Lieu de Vie :</label>
                <input type="text" name="lieuDeVie" id="lieuDeVie" value="<?= $utilisateur->gvrUT ?>">
</div>
            <div>
                <label for="genre">Genre :</label>
                <input type="text" name="genre" id="genre" value="<?= $utilisateur->genre ?>">
</div>
            <div>
                <label for="password">Mot de passe :</label>

                <input type="password" name="password" id="password" value="<?= $utilisateur->mdp ?>">
</div>
            <input type="hidden" name="controller" value="utilisateur">
            <input type="hidden" name="action" value="modif2">
            <input type="submit" value="Modifier" /> 
        </form>
</section>

<footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
      
    </footer>
</body>
</html>