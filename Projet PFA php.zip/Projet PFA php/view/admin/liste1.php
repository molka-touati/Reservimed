<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin de Reservimed</title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Liste.css"/>
</head>

<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php?controller=admin&action=lister">ADMIN PAGE  </a>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php?controller=utilisateur&action=lister">Listes des utilisateurs</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php?controller=medecin&action=lister">Listes des Medecins </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php?controller=commentaire&action=lister">Liste de commentaires </a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="index.php?controller=rdv&action=lister">Liste de rendez_vous</a>
      </li>
    </ul>
  </div>
</nav>
</header>
</html>