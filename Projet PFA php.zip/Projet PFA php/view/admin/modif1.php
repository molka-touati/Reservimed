<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/form.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <title> Admin ReserviMed.tn || Modifier Admin </title>
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>

<body>
<section class="form-sec">
        
          
        <form action="index.php?controller=admin&action=modif2" method="post">
          <legend><h1><strong>Modifier un Admin</h1></strong></legend>
        <div>
		 <label for="cin">CIN :</label> 
		 <input type="text"  name="cin" id="cin"  value="<?= $admin->CIN ?>"/>
         </div> 
    <div>
		 <label for="nom">Nom :</label> 
		 <input type="text"  name="nom" id="nom"   value="<?= $admin->Nom ?>"/>
         </div> 
    <div>
		 <label for="email">Email :</label> 
		 <input type="email"  name="email" id="email"   value="<?= $admin->Email ?>"/>
         </div> 
        
         <div>
		 <label for="mdp">Password :</label> 
		 <input type="password"  name="mdp" id="mdp"   value="<?= $admin->Password ?>"/>
         </div>
         
         <input type="submit" value="Modifier" /> 
         
        </form>
</section>
<footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
      
    </footer>
</body>
</html>