<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion Admin || ReserviMed.tn</title>
    <link rel="stylesheet" href="../../CSS/admincnx.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<section id="connexion">
          <div class="container">
              <div class="formulaire">
                  <div class="connexion">
                      <h1><strong>Connectez-vous || Admin</strong></h1>
                      <form method="post" action="../../index.php?controller=admin&action=sign_in">
                          <input type="text" style="border-radius:9px;" name="email" placeholder="  Email">
                          <input type="password" style="border-radius:9px;" name="password" placeholder="  Mot de passe" required>
                          <input style="width:50%; height: 50px; margin-left: 22%; background-color:  #0097b2c4; border-radius:9px; border: 0; padding: 10px;font-size: 20px;font-weight: bold;color: white;" type="submit"  value="Se connecter"><br><br> 
                      </form>
                  </div>
      </section>
</body>
</html>