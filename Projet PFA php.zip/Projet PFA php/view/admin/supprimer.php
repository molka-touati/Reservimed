<?php
if($resultat){
    echo "<p>Bravo! Suppression avec succès.</p>";
}
else{
    echo "<p>user introuvable!</p>";
}
?>
<a href="index.php?controller=admin&action=lister">Retour à la page d'accueil</a>