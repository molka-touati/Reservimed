<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>ReserviMed.tn || Page de Connexion</title>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <link rel="stylesheet" href="CSS/connexion.css"/>
    
    <script src="JS/connexion.js" defer></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="navbar"> 
        <header >
        </header>
        <nav >
          
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
              <a href="accueil.php">Accueil</a>
                <a href="accueil.php #s4">Discuter</a>
                <a href="#">Se connecter</a>
                <a href="#registerButton">S'inscrire </a>
                <div class=" search-bar ">
                    <form>
                        <div class="search-bar-box flex">
                            <input type="search" class="search-control" placeholder="Rechercher">
                        </div>
                    </form>
                </div>
            </div>
        </nav>
        
        
    </div>
   <div> 
        <section id="connexion">
          <div class="container">
              <div class="formulaire">
                  <div class="connexion">
                      <h1><strong>Connectez-vous</strong></h1>
                      <form method="post" action="index.php?controller=utilisateur&action=sign_in">
                          <input type="text" name="email" placeholder="  Email">
                          <input type="password" name="password" placeholder="  Mot de passe" required>
                          <input style="width:50%; height: 50px; margin-left: 22%; background-color:  #0097b2c4; border-radius: 10px; border: 0; padding: 10px;font-size: 20px;font-weight: bold;color: white;" type="submit"  value="Se connecter"><br><br> 
                      </form>
                  </div>
                  <div class="bienvenue">
                        <h2><strong>Nouveau sur notre site ?</strong></h2>
                        <p><strong>Créez votre compte et rejoignez notre communauté .<strong></p>
                        <button type="button" id="registerButton">Inscrivez-vous</button>
                    </div>
              </div>
          </div>
      </section>
      <section id="inscriptionSection" class="hidden">
        <div class="wrapper">
          <div class="form-container">
            <h1>Inscription</h1>
            <form id="inscriptionForm" method="post" action="index.php?controller=utilisateur&action=ajoutuser">
              <div class="input-group">
                <input type="text" id="nom" name="nom" placeholder="Nom" required>
                <div class="error-message" id="nomErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="text" id="prenom" name="prenom" placeholder="Prénom" required>
                <div class="error-message" id="prenomErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="email" id="emailReg" name="email" placeholder="Adresse email" required>
                <div class="error-message" id="emailErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="text" id="cin" name="cin" pattern="[0-9]{8}" placeholder="Numéro CIN " required>
                <div class="error-message" id="cinErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="tel" id="telephone" name="telephone" pattern="[0-9]{8}" placeholder="Numéro de téléphone" required>
                <div class="error-message" id="telephoneErrorMessage"></div>
              </div>
              <div class="input-group">
                <label for="date_naissance" style="font-size:20px;" >Date de Naissance :</label>
                <input type="date" id="date_naissance" name="date_naissance" required>
              </div>
              <div class="input-group">
                <select id="lieuDeVie" name="lieuDeVie" required>
                  <option value="">Choisir votre Gouvernaurat</option>
                  <option value="Ariana">Ariana</option>
                  <option value="Béja">Béja</option>
                  <option value="Ben Arous">Ben Arous</option>
                  <option value="Bizerte">Bizerte</option>
                  <option value="Gabès">Gabès</option>
                  <option value="Gafsa">Gafsa</option>
                  <option value="Jendouba">Jendouba</option>
                  <option value="Kairouan">Kairouan</option>
                  <option value="Kasserine">Kasserine</option>
                  <option value="Kébili">Kébili</option>
                  <option value="Mahdia">Mahdia</option>
                  <option value="Manouba">Manouba</option>
                  <option value="Médenine">Médenine</option>
                  <option value="Monastir">Monastir</option>
                  <option value="Nabeul">Nabeul</option>
                  <option value="Sfax">Sfax</option>
                  <option value="Sidi Bouzid">Sidi Bouzid</option>
                  <option value="Silana">Silana</option>
                  <option value="Sousse">Sousse</option>
                  <option value="Tataouine">Tataouine</option>
                  <option value="Tozeur">Tozeur</option>
                  <option value="Tunis">Tunis</option>
                  <option value="Zaghouan">Zaghouan</option>
                  </select>
                <div class="error-message" id="lieuDeVieErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="text" id="ville" name="ville" placeholder="Votre ville " required>
              </div>
              <div class="input-group">
                <input type="password" id="password" name="password" placeholder="Mot de passe" required>
                <div class="error-message" id="passwordErrorMessage"></div>
              </div>
              <div class="input-group">
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirmer le mot de passe" required>
                <div class="error-message" id="confirmPasswordErrorMessage"></div>
              </div><br><br><br>
              <div class="genre">
                <label style="font-size: 20px;"for="genre">Genre:</label>
                <input type="radio" id="genreM" name="genre" value="Masculin" required> <label for="genreM">Masculin</label>
                <input type="radio" id="genreF" name="genre" value="Féminin" required><label for="genreF">Féminin</label>
              </div>
              <br>
                    <div class="button-group">
                        <input type="submit" value="S'inscrire">
                        <button type="reset"id="cancelButton">Annuler</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <footer>
      <div >
        <h5 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2) 
          <br><br>ReserviMed.tn &copy; 2023-2024</strong> </h5> 
      </div>
      
    </footer>
  
</body>
</html>