<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin ReserviMed.tn || Liste Commentaire </title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Liste.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>
<body>
<br><br>
<section>
        
        <h2 class="titre"><strong>Liste des Commentaires</strong></h2>

        <p>Nombre de commentaires  trouvés : <?= count($listecmnts) ?></p>
        <table >
        <thead>
          <tr>
            <th >Identifiant</th>
            <th >CIN</th>
            <th >Nom</th>
            <th >Commentaire </th>
        </tr>
       </thead>
       <tbody>
        <tr>
        <?php
        foreach($listecmnts as $cmnt){
        ?>  
            <td><?= $cmnt->IDCM ?></td>
            <td><?= $cmnt->CIN ?></td>
            <td> <?= $cmnt->Nom ?></td>
            <td> <?= $cmnt->Cmnt ?></td>
            <td><a href="index.php?controller=commentaire&action=delete&cin=<?= $cmnt->CIN ?>" class="btn btn-danger text-light " ><h6><strong>Supprimer</strong> </h6></a></td>
        </tr>
        </tbody>
        <?php
        }
        ?>
 </section>

</body>
</html>