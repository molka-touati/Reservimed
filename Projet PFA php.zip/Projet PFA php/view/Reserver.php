<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Site web de reservation de rendez-vous en ligne d'une consultation   " />
    <meta name="keywords" content=" Rendez-vous , medecin , patient , consultation "/>

    <link rel="stylesheet" href="../CSS/bootstrap.css"/>
    <link rel="stylesheet" href="../CSS/Style.css"/>
    <link rel="stylesheet" href="../CSS/Reserver.css"/>
    
    
    
    <script src="JS/Reserver.js"></script>
    <title> ReserviMed.tn || Formulaire de Reservation </title>
</head>

<body>
    <div class="navbar"> 
        <header >
        </header>
        <nav >
            <img src="../Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="../index.php?controller=utilisateur&action=lister_user">Accueil</a>
            <a href="../index.php?controller=medecin&action=lister_user">Liste des médecin</a>
            <a href="../index.php?controller=utilisateur&action=lister_user ">Discuter</a>
            <a href="../index.php?controller=utilisateur&action=ajout1">S'inscrire </a> 
            <div class="search-bar">
                    <form>
                        <div class="search-bar-box flex">
                            <input type="search" class="search-control" id="searchInput" placeholder="Rechercher">
                        </div>
                    </form>
                    <div id="searchResults"></div>
                </div>
            </div>
        </nav>
        
    </div>
    <section>
        <article>
            <br>
            <h2 ><strong>Réservez un Rendez-vous </strong></h2> 
            <?php $mdc=$_GET["id_medecin"];?>
                <div class="form-container " >
                    <form action="../index.php?controller=rdv&action=ajout2&medecin=<?=$mdc?>" method="post" name="FormReservation" >
                        <div class="formpad ">
                            <div class="form-row">
                                <div>
                                    <input type="text" id="nom" name="nom" class="form-input" placeholder="Nom" title="Entrez votre nom" required>
                                </div>
                                <div>
                                    <input type="text" id="prenom" name="prenom" class="form-input" placeholder="Prénom" title="Entrez votre prénom" required>
                                </div>
                            </div>
                            <div>
                                <input type="text" id="cin" name="cin" class="form-input" placeholder="CIN" title="Entrez votre CIN" required>
                            </div>
                            <div>
                                <input type="email" id="email" name="email" class="form-input" placeholder="Email" title="Entrez votre adresse email" required>
                            </div>
                            <div>
                                <input type="tel" id="numero" name="numero" class="form-input" placeholder="Numéro de téléphone" title="Entrez votre numéro de téléphone" pattern="[0-9]{8}" required>
                            </div>
                            <div class="form-row">
                                
                                <div>
                                    <input type="date" id="date" name="date" class="form-input" placeholder="Date" title="Sélectionnez une date" required>
                                </div>
                                <div>
                                    <input type="time" id="heure" name="heure" class="form-input" placeholder="Heure" title="Sélectionnez une heure" required>
                                </div>
                            </div>
                        </div>
                            <div class="form-rowb">
                                
                                <button type="submit" class="form-button"><strong>Réserver</strong></button>
                                <button type="reset" class="form-button"><strong>Annuler</strong></button>
                            </div>
                        
                            

                        <div class="error-message" id="error-message">Veuillez remplir tous les champs.</div>
                        <div class="success-message" id="success-message">Réservation réussie!</div>
                    </form>
                </div>
            

        </article>
    </section>
    <footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      
    </footer>

    <script src="../JS/jquery-3.7.1.min.js"></script>
    <script src="../JS/popper.min.js"></script>
    <script src="../JS/bootstrap.js"></script>
    <script src="../JS/Reserver.js"></script>
    <script src="../JS/recherche.js"></script>


</body>

</html>