<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/form.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <title> Admin ReserviMed.tn || Modifier RDV </title>
    
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>
<body>

<section class="form-sec">

        <form action="index.php?controller=rdv&action=modif2" method="post" name="FormReservation" id="FR">
          <legend><h1><strong>Modifier un Rendez-vous</h1></strong></legend>
        
                        
                            
                                <div>
                                    <input type="text" id="nom" name="nom"  placeholder="Nom" title="Entrez votre nom" value="<?= $rdv->Nom ?>">
                                </div>
                                <div>
                                    <input type="text" id="prenom" name="prenom"  placeholder="Prénom" title="Entrez votre prénom" value="<?= $rdv->Prenom ?>">
                                </div>
                            
                            <div>
                                <input type="text" id="cin" name="cin"  placeholder="CIN" title="Entrez votre CIN" value="<?= $rdv->CIN ?>">
                            </div>
                            <div>
                                <input type="email" id="email" name="email" placeholder="Email" title="Entrez votre adresse email" value="<?= $rdv->Email ?>">
                            </div>
                            
                            <div>
                                <input type="text" id="numero" name="numero"  placeholder="Numéro de téléphone" title="Entrez votre numéro de téléphone" pattern="[0-9]{8}" value="<?= $rdv->Numtel ?>">
                            </div>

                           <div>
                                    <input type="date" id="date" name="date" placeholder="Date" title="Sélectionnez une date" value="<?= $rdv->dateRDV ?>">
                                </div>
                                <div>
                                    <input type="time" id="heure" name="heure"  placeholder="Heure" title="Sélectionnez une heure" value="<?= $rdv->heureRDV ?>">
                                </div>
                                <br>
                            
                       
                        <input type="submit" value="Modifier" />
                    
                </form>
                
            

        
    </section>
    <footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
      
    </footer>
</body>
</html>