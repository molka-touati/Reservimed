<?php
if($resultat){
    echo "<p>Bravo! Modification avec succès.</p>";
}
else{
    echo "<p>Echec!</p>";
}
?>
<a href="index.php?controller=rdv&action=lister">Retour à la page d'accueil</a>