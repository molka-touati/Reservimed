<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin ReserviMed.tn || Liste RDV </title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Liste.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
</head>
<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>

<body>
  <br><br>
  <section>
   
   <h2 class="titre"><strong>Liste de Rendez_Vous</strong></h2>
        

        <p>Nombre de rendez_vous trouvés : <?= count($listerdv) ?></p>
        <table >
        <thead>
          <tr>
            <th >codeRDV</th>
            <th >Nom</th>
            <th >Prenom</th>
            <th >Num telephone</th>
            <th >Mail</th>
            <th >CIN</th>
            <th >Date RDV </th>
            <th >heure RDV</th>
            <th >IDMD </th>
        </tr>
       </thead>
       <tbody>
        <tr>
        <?php
        foreach($listerdv as $rdv){
        ?>
            <td> <?= $rdv->codeRDV ?></td>
            <td> <?= $rdv->Nom ?></td>
            <td> <?= $rdv->Prenom ?></td>
            <td> <?= $rdv->Numtel ?></td>
            <td> <?= $rdv->Email ?></td>
            <td><?= $rdv->CIN ?></td>
            <td> <?= $rdv->dateRDV ?></td>
            <td><?= $rdv->heureRDV ?></td>
            <td> <?= $rdv->IDMD ?></td>
            <td>
            <div>
                <a href="index.php?controller=rdv&action=modif&cin=<?= $rdv->CIN ?>" class="btn btn-success text-light " ><h6><strong>Modifier</strong> </h6></a>
              
                <a href="index.php?controller=rdv&action=delete&cin=<?= $rdv->CIN ?>" class="btn btn-danger text-light " ><h6><strong>Supprimer</strong> </h6></a>
              </div>  
               
        </tr>
        </tbody>
        <?php
        }
        ?>
        </section>
</body>
</html>