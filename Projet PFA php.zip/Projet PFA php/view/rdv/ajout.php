<?php
if($resultat){
    echo "<p>Nous vous contacterons ultérieurement pour confirmer le rendez-vous. </p>";
}
else{
    echo "<p>Erreur!</p>";
}
?>
<a href="index.php?controller=medecin&action=lister_user">Retour à la page d'accueil</a>