<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Site web de reservation de rendez-vous en ligne d'une consultation   " />
    <meta name="keywords" content=" Rendez-vous , medecin , patient , consultation "/>
    
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    
    <link rel="stylesheet" href="CSS/Style.css"/>
    <link rel="stylesheet" href="CSS/ListeMed.css"/>
    
    <title> ReserviMed.tn || Liste Médecin </title>
</head>

<body >

    <div class="navbar"> 
        <header >
        </header>
        
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
                <a href="index.php?controller=utilisateur&action=lister_user">Accueil</a>
                <a href="#">Liste des médecin</a>
                <a href="index.php?controller=utilisateur&action=lister_user ">Discuter</a>
                
                <a href="index.php?controller=utilisateur&action=ajout1">S'inscrire </a>
                               
                <div class="search-bar">
                    <form>
                        <div class="search-bar-box flex">
                            <input type="search" class="search-control" id="searchInput" placeholder="Rechercher">
                        </div>
                    </form>
                    <div id="searchResults"></div>
                </div>
            </div>
        </nav>
        
    </div>

    <!-- barre de recherche -->
    
    <div class="dropdown  dropdownetat">
        <div class="btn btn-light text-info btn-lg dropdown-toggle" id="X" data-toggle="dropdown"><strong>Choisir un Gouvernorat</strong>  </div>
        <div class="dropdown-menu " aria-labelledby="X">
            <a href="#GTunis" class="dropdown-item ">Grand Tunis</a>
            <a href="#SS" class="dropdown-item">Sousse</a>
            <a href="#Nb" class="dropdown-item">Nabeul</a>
            <a href="#Mon" class="dropdown-item">Monastir</a>
        </div>
    </div>
    <br>
    <section class="espaceBloc" >
         <h1 id="GTunis"><strong>Grand Tunis</strong>  </h1>
        <article class="bloc" > 
            <?php foreach($listemedecin as $med){
                if($med->gvrMD == "Grand Tunis"){?>  
                <div class="bloc1"> 
                    <h4> <strong> <?= $med->specMD ?> </strong>  </h4>
                    <div class="content-section">
                        <div class="image-container">
                            <img src="<?= $med->Image ?>" alt="PhotoMed" class="image"  >
                        </div>
                        <div class="text-container ">
                            <br>
                            <p> <?= $med->prenomMD ?> <?= $med->nomMD ?>  </p>
                            <p> <a href="tel:+216<?= $med->numtelMD ?>"><?= $med->numtelMD?> </a> </p>
                            <p><a href="mailto:<?= $med->emailMD?>.tn" > <?= $med->emailMD?> </a></p>
                            <p> <a href="<?= $med->localMD ?>"><?= $med->localMD ?> </a></p>
                            <div >
                                <div class="centre">
                                    <ul>
                                        <li><a href="<?= $med->fbMD ?>" >
                                                <img src="Images/Facebook logo png.png" alt="Logo Facebook" title="Lien vers page Facebook" width="20px">
                                        </a></li>
                                        <li><a href="<?= $med->instaMD ?>" >
                                            <img src="Images/Insta logo png.png" alt="Logo Instagram " title="Lien vers page Instagram" width="20px" >
                                        </a></li>
                                        <li><a href="tel:+216 <?= $med->numtelMD ?>" >
                                            <img src="Images/Tel Logo png.png" alt="Telephone " title="Passer un appel" class="margin-botton:10px;" width="29px"> 
                                        </a></li>
                                        <li><a href="https://maps.app.goo.gl/Lqahr5zCMcRvmSkD7">
                                            <img src="Images/localisation Logo png .png" alt="Localisation" title="Localisation du Medecin" width="22px">
                                        </a></li> 
                                    </ul>
                                </div>
                                <div>
                                <a href="view/Reserver.php?id_medecin=<?= $med->IDMD ?>" class="btn btn-info btn-lg buttonPlc" ><h6>Réserver </h6></a> 
                                </div>
                            </div>
                        </div>  
                    </div>
                    </div>
                    <?php }} ?>
                <br>  
            </article>
        </section>
        <!-- Médecin en Sousse -->
        <section class="espaceBloc" >
            <h1 id="SS"><strong>Sousse</strong>  </h1>
            <article class="bloc" >    
            <?php foreach($listemedecin as $med){
                if($med->gvrMD == "Sousse"){?> 
                <div class="bloc1">
                    <h4> <strong> <?= $med->specMD ?> </strong>  </h4>
                    <div class="content-section">
                        <div class="image-container">
                        <img src="<?= $med->Image ?>" alt="PhotoMed" class="image"  >
                        </div>
                        <div class="text-container ">
                            <br>
                            <p> <?= $med->prenomMD ?> <?= $med->nomMD ?>  </p>
                            <p> <a href="tel:+216<?= $med->numtelMD ?>"><?= $med->numtelMD?> </a> </p>
                            <p><a href="mailto:<?= $med->emailMD?>.tn" > <?= $med->emailMD?> </a></p>
                            <p> <a href="<?= $med->localMD ?>"><?= $med->localMD ?> </a></p>
                            <div >
                                <div class="centre">
                                    <ul>
                                        <li><a href="<?= $med->fbMD ?>" >
                                                <img src="Images/Facebook logo png.png" alt="Logo Facebook" title="Lien vers page Facebook" width="20px">
                                        </a></li>
                                        <li><a href="<?= $med->instaMD ?>" >
                                            <img src="Images/Insta logo png.png" alt="Logo Instagram " title="Lien vers page Instagram" width="20px" >
                                        </a></li>
                                        <li><a href="tel:+216 <?= $med->numtelMD ?>" >
                                            <img src="Images/Tel Logo png.png" alt="Telephone " title="Passer un appel" class="margin-botton:10px;" width="29px"> 
                                        </a></li>
                                        <li><a href="https://maps.app.goo.gl/Lqahr5zCMcRvmSkD7">
                                            <img src="Images/localisation Logo png .png" alt="Localisation" title="Localisation du Medecin" width="22px">
                                        </a></li> 
                                    </ul>
                                </div>
                                <div>
                                <a href="view/Reserver.php?id_medecin=<?= $med->IDMD ?>" class="btn btn-info btn-lg buttonPlc" ><h6>Réserver </h6></a>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                <?php }} ?>
                <br>  
            </article>
        </section>

<!-- Médecin en Monastir -->
           <section class="espaceBloc" >
            <h1 id="Mon"><strong>Monastir</strong>  </h1>
            <article class="bloc" > 
            <?php foreach($listemedecin as $med){
                if($med->gvrMD == "Monastir"){?>
                 <div class="bloc1">
                    <h4> <strong> <?= $med->specMD ?> </strong>  </h4>
                    <div class="content-section">
                        <div class="image-container">
                        <img src="<?= $med->Image ?>" alt="PhotoMed" class="image"  >
                        </div>
                        <div class="text-container ">
                            <br>
                            <p> <?= $med->prenomMD ?> <?= $med->nomMD ?>  </p>
                            <p> <a href="tel:+216<?= $med->numtelMD ?>"><?= $med->numtelMD?> </a> </p>
                            <p><a href="mailto:<?= $med->emailMD?>.tn" > <?= $med->emailMD?> </a></p>
                            <p> <a href="<?= $med->localMD ?>"><?= $med->localMD ?> </a></p>
                            <div >
                                <div class="centre">
                                    <ul>
                                        <li><a href="<?= $med->fbMD ?>" >
                                                <img src="Images/Facebook logo png.png" alt="Logo Facebook" title="Lien vers page Facebook" width="20px">
                                        </a></li>
                                        <li><a href="<?= $med->instaMD ?>" >
                                            <img src="Images/Insta logo png.png" alt="Logo Instagram " title="Lien vers page Instagram" width="20px" >
                                        </a></li>
                                        <li><a href="tel:+216 <?= $med->numtelMD ?>" >
                                            <img src="Images/Tel Logo png.png" alt="Telephone " title="Passer un appel" class="margin-botton:10px;" width="29px"> 
                                        </a></li>
                                        <li><a href="https://maps.app.goo.gl/Lqahr5zCMcRvmSkD7">
                                            <img src="Images/localisation Logo png .png" alt="Localisation" title="Localisation du Medecin" width="22px">
                                        </a></li> 
                                    </ul>
                                </div>
                                <div>
                                <a href="view/Reserver.php?id_medecin=<?= $med->IDMD ?>" class="btn btn-info btn-lg buttonPlc" ><h6>Réserver </h6></a> 
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                <?php }} ?>
                <br>  
            </article>
        </section>      
       
        <section class="espaceBloc" >
        <h1 id="Nb"><strong>Nabeul</strong>  </h1>
        <article class="bloc" >
        <?php foreach($listemedecin as $med){
                if($med->gvrMD == "Nabeul"){?> 
        <div class="bloc1">
                    <h4> <strong> <?= $med->specMD ?> </strong>  </h4>
                    <div class="content-section">
                        <div class="image-container">
                        <img src="<?= $med->Image ?>" alt="PhotoMed" class="image"  >
                        </div>
                        <div class="text-container ">
                            <br>
                            <p> <?= $med->prenomMD ?> <?= $med->nomMD ?>  </p>
                            <p> <a href="tel:+216<?= $med->numtelMD ?>"><?= $med->numtelMD?> </a> </p>
                            <p><a href="mailto:<?= $med->emailMD?>.tn" > <?= $med->emailMD?> </a></p>
                            <p> <a href="<?= $med->localMD ?>"><?= $med->localMD ?> </a></p>
                            <div >
                                <div class="centre">
                                    <ul>
                                        <li><a href="<?= $med->fbMD ?>" >
                                                <img src="Images/Facebook logo png.png" alt="Logo Facebook" title="Lien vers page Facebook" width="20px">
                                        </a></li>
                                        <li><a href="<?= $med->instaMD ?>" >
                                            <img src="Images/Insta logo png.png" alt="Logo Instagram " title="Lien vers page Instagram" width="20px" >
                                        </a></li>
                                        <li><a href="tel:+216 <?= $med->numtelMD ?>" >
                                            <img src="Images/Tel Logo png.png" alt="Telephone " title="Passer un appel" class="margin-botton:10px;" width="29px"> 
                                        </a></li>
                                        <li><a href="https://maps.app.goo.gl/Lqahr5zCMcRvmSkD7">
                                            <img src="Images/localisation Logo png .png" alt="Localisation" title="Localisation du Medecin" width="22px">
                                        </a></li> 
                                    </ul>
                                </div>
                                <div>
                                <a href="view/Reserver.php?id_medecin=<?= $med->IDMD ?>" class="btn btn-info btn-lg buttonPlc" ><h6>Réserver </h6></a>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                <?php }} ?>
                <br>  
        </article>
    </section>

    <footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
    </footer>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="JS/recherche.js"></script>

</body>
</html>