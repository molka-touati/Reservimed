<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/form.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <title> Admin ReserviMed.tn || Modifier Medecin </title>
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>

<body>
<section class="form-sec">
        <form action="index.php?controller=medecin&action=modif2" method="post">
          <legend><h1><strong>Modifier un Medecin</h1></strong></legend>
 
        <div>
		 <label for="id">ID Medecin :</label> 
		 <input type="text"  name="id" id="id" value="<?= $med->IDMD ?>"/>
         </div> 
	 <div>
		 <label for="nommed">Nom :</label> 
		 <input type="text"  name="nommed" id="nommed"  value="<?= $med->nomMD ?>"/>
         </div> 
	 <div>
     <label for="prenommed">Prenom :</label> 
     <input type="text" name="prenommed" id="prenommed" value="<?= $med->prenomMD ?>"/>
     </div> 
     <div>
     <label for="emailmed">Email :</label> 
     <input type="email" name="emailmed" id="emailmed" value="<?= $med->emailMD ?>"/>
     </div> 
     <div>
     <label for="telephonemed">Téléphone :</label> 
     <input type="text" name="telephonemed" id="telephonemed"  value="<?= $med->numtelMD ?>"/>
     </div> 
     <div>
     <label for= "specmed">Spécialité :</label> 
     <input type="text" name="specmed" id="specmed"  value="<?= $med->specMD ?>"/>
     </div> 
     <div>
     <label for="localmed">Local :</label> 
     <input type="text" name="localmed" id="localmed"  value="<?= $med->localMD ?>"/>
     </div> 
     <div>
     <label for="lieuDeVie">Gouvernaurat :</label> 
       <input type="text" name="lieuDeVie" id="lieuDeVie"  value="<?= $med->gvrMD ?>"/>    
     </div>
     <div>
         <label for="fbmed">Facebook :</label> 
            <input type="url" name="fbmed" id="fbmed" value="<?= $med->fbMD ?>" />
         </div> 
                <div>
        <label for="instamed">Instagram :</label> 
          <input type="url" name="instamed" id="instamed"  value="<?= $med->instaMD ?>"/>
        </div>
        <div> 
           <label for="datedispo">Date de disponibilité :</label> 
          <input type="text" name="datedispo" id="datedispo" value="<?= $med->dispoMD ?>" />
           </div> 
           <div>
           <input type="hidden" name="controller" value="medecin">
            <input type="hidden" name="action" value="modif2">
           </div>
                
                <input type="submit" value="Modifier" /> 

        </form>
</section>
<footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
      </div>
      <br>
      
    </footer>

</body>
</html>