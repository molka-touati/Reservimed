<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin ReserviMed.tn || Liste Medecin </title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Liste.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
</head>

<header class="navbar">
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
            <a href="index.php?controller=admin&action=lister" >ADMIN PAGE </a>
            <a  href="index.php?controller=utilisateur&action=lister">Utilisateurs</a>
            <a href="index.php?controller=medecin&action=lister">Medecins </a>
            <a  href="index.php?controller=commentaire&action=lister">Commentaires </a>
            <a  href="index.php?controller=rdv&action=lister"> Rendez_Vous</a>
            
            </div>
        </nav>
</header>


<body>
  <br><br>
 <section >     
      <h2 class="titre"><strong>Liste des Médecins</strong></h2>

      <p>Nombre de médecins  trouvés : <?= count($listemedecin) ?></p>
      <div>
        <a href="index.php?controller=medecin&action=ajout" class="btn btn-light btn-lg text-info " ><h6><strong>Ajouter un médecin</strong> </h6></a>
      </div>
<br>
    <table>
        <thead>
          <tr>
            <th >Identifiant</th>
            <th >Nom</th>
            <th >Prenom</th>
            <th >Mail</th>
            <th >Num telephone</th>
            <th >Spécialité</th>
            <th >Gouvernaurat</th>
            <th > Ville</th>
            <th >Facebook </th>
            <th >Instagram</th>
            <th >Disponibilité</th>
            <th>Modifier ou Supprimer</th>
        </tr>
       </thead>
       <tbody>
        <tr>
        <?php
        foreach($listemedecin as $med){
        ?>  <td><?= $med->IDMD ?></td>
            <td> <?= $med->nomMD ?></td>
            <td> <?= $med->prenomMD ?></td>
            <td> <?= $med->emailMD ?></td>
            <td> <?= $med->numtelMD ?></td>
            <td> <?= $med->specMD?></td>
            <td><?= $med->gvrMD ?></td>
            <td> <?= $med->localMD ?></td>
            <td> <?= $med->fbMD ?></td>
            <td><?= $med->instaMD ?></td>
            <td><?= $med->dispoMD ?></td>
            <td>
            <div>
                <a href="index.php?controller=medecin&action=modif&id=<?= $med->IDMD ?>" class="btn btn-success text-light " ><h6><strong>Modifier</strong> </h6></a>
              
                <a href="index.php?controller=medecin&action=delete&id=<?= $med->IDMD ?>" class="btn btn-danger text-light " ><h6><strong>Supprimer</strong> </h6></a>
              </div>  
              
        </td>
        </tr>
        </tbody>
        <?php
        }
        ?>
        </section>
</body>
</html>