<?php
if($resultat){
    echo "<p>Bravo! Ajout avec succès.</p>";
}
else{
    echo "<p>Erreur!</p>";
}
?>
<a href="index.php?controller=medecin&action=lister">Retour à la page d'accueil</a>