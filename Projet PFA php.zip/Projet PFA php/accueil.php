
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>ReserviMed.tn || Page d'Accueil </title>
    <link rel="stylesheet" href="CSS/bootstrap.css"/>
    <link rel="stylesheet" href="CSS/Style.css"/>
    <link rel="stylesheet" href="CSS/accueil.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="navbar"> 
        <header >
        </header>
        
        <nav >
            <img src="Images/logo.png" alt="Logo du site">
            <div class="ndiv">
                <a href="#">Accueil</a>
                <a href="#s4">Discuter</a>
                <a href="index.php?controller=utilisateur&action=ajout1">Se connecter</a>
                <a href="index.php?controller=utilisateur&action=ajout1 ">S'inscrire </a>
                
                
                <div class=" search-bar ">
                    <form>
                        <div class="search-bar-box flex">
                            <input type="search" class="search-control" placeholder="Rechercher">
                        </div>
                    </form>
                </div>
            </div>
        </nav>
    </div>
   <div> 
   <section id="s1">
      <span class="description">
      <h2 style="font-size: 30px;">Découvrez <strong><span style="color:#087596;">ReserviMed.tn </span> </strong>: la solution idéale <br> pourréserver vos rendez-vous médicaux en ligne <br> en toute simplicité !</h2><br> 
          <a href="#s3" id="explorer" style="text-decoration: none;"><strong>Explorer &#8594</strong></a>
      </span>
          <img src="Images/bg.png">
  </section>
</div>
<br><br>

<section id="s2">
  <div class="bloc-map">
  <p >
    <br><br>
  Découvrez les médecins près de chez vous et réservez facilement vos consultations en quelques clics .<br>
  Pour accéder à la liste complète des médecins et profiter de notre service de réservation , inscrivez-vous ou connectez-vous dès maintenant .
    </p>
  <div id="map-container">
    <img src="Images/tun.png" alt="Carte de Tunis">
  </div>
</div>
</section>
<br><br>
<section id="s3" class="features">
<h1><strong>Principales Fonctionnalités</strong></h1>
<br>
<div class="features-container">
<div class="feature">
  <i class="fa-solid fa-calendar-check"></i>
  <h4><strong>Prise de rendez-vous simple</strong></h4>
  <p><strong>Trouvez le spécialiste qui vous convient et réservez un créneau horaire en ligne .</strong></p>
</div>
<div class="feature">
  <i class="fa-solid fa-user-doctor"></i>
  <h4><strong>Large choix de médecins</strong></h4>
  <p><strong>Accédez à un réseau de professionnels qualifiés dans de nombreuses spécialités .</strong></p>
</div>
<div class="feature">
  <i class="fa-solid fa-clock"></i>
  <h4><strong>Gain de temps et flexibilité<strong></h4>
  <p>Réservez vos rendez-vous en dehors des heures de bureau et gagnez du temps .</p>
</div>
<div class="feature">
  <i class="fa-solid fa-file-medical"></i>
  <h4><strong>Gestion des dossiers médicaux<strong></h4>

  <p>Accédez à vos dossiers médicaux et aux ordonnances en toute sécurité .</p>
</div>
</div>
</section>
   <section id="s4">
    <div class="comment-section">
      <h2 style="color: #087596;"><strong>Laissez votre avis</strong></h2>
      <form method="post" action="index.php?controller=commentaire&action=ajout2">
        <div class="comment-form">
          <input type ="text" name="cin" placeholder="votre cin" required>
          <input type="text" name="nom" placeholder="Votre nom" required>
          <textarea name="commentaire" placeholder="Votre commentaire" required></textarea>
        </div>
       <div class="submit-btn">
        <input type="submit" name="submit" value="Envoyer">
        <button type="reset"id="cancelButton">Annuler</button>
       </div>
   </form>
    </div>
  </section>
  <br><br><br>
    <footer>
      <div >
        <h6 ><strong> Projet réalisé par : Molka Zaki Touati - Ranim Tobji (L2 BI G2)</strong> </h6> 
        <h6 ><strong> ReserviMed.tn &copy; 2023-2024</strong> </h6>
        
      </div>
      <br>
    </footer>
</body>
</html>
    