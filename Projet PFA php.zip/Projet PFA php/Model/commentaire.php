<?php
require_once "Model.php";

class commentaire extends Model{

    public $IDCM;
    public $Nom;
    public $Cmnt;
    public $CIN;

    protected $table = "commentaire";
    protected $clePrimaire = "CIN";
}
?>