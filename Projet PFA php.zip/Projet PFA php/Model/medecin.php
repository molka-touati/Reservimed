<?php
require_once "Model.php";

class medecin extends Model{

    public $IDMD;
    public $nomMD;
    public $prenomMD;
    public $emailMD;
    public $numtelMD;
    public $specMD;
    public $gvrMD;
    public $localMD;
    public $fbMD;
    public $instaMD;
    public $dispoMD;

    protected $table = "medecin";
    protected $clePrimaire = "IDMD";

}
?>