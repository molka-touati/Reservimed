<?php
require_once "Model.php";

class rdv extends Model{

    public $codeRDV;
    public $Nom;
    public $Prenom;
    public $Email;
    public $Numtel;
    public $dateRDV;
    public $heureRDV;
    public $IDMD;
    public $CIN;

    protected $table = "rdv";
    protected $clePrimaire = "CIN";
    
}
?>.