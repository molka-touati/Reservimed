<?php
require_once "Model.php";

class administrateur extends Model{

    public $codeAD;
    public $CIN;
    public $Nom;

    protected $table = "administrateur";
    protected $clePrimaire = "CIN";
    


public function getByEmail($email){
    // Se connecter à la base de données
    $db = self::connect();
    $email=$db->quote($email);
    // Créer une chaîne de caractère contenant la requête à exécuter
    $sql = "SELECT * FROM administrateur where Email= $email";
    try{
        $resultat = $db->query($sql); // Exécuter la requêtes SQL
        if($resultat->rowCount() == 1){
            $record = $resultat->fetchObject();
            return $record;
        }
        else{
            return false;
        }
    }
    catch(PDOException $ex){
        die($ex->getMessage());
    }
    finally{
        // Libérer les ressources
        $resultat->closeCursor();
    }
} }
?>