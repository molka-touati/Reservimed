<?php
require_once "Model.php";

class ModelUtilisateur extends Model{

    public $pkuser;
    public $CIN;
    public $nomUT;
    public $prenomUT;
    public $emailUT;
    public $ddn;
    public $genre;
    public $numtel;
    public $villeUT;
    public $gvrUT;
    public $mdp;

    protected  $table = "userreservimed";
    protected  $clePrimaire = "CIN";
    public function getByEmail($email){
        // Se connecter à la base de données
        $db = self::connect();
        $email=$db->quote($email);
        // Créer une chaîne de caractère contenant la requête à exécuter
        $sql = "SELECT * FROM userreservimed where emailUT= $email";
        try{
            $resultat = $db->query($sql); // Exécuter la requêtes SQL
            if($resultat->rowCount() == 1){
                $record = $resultat->fetchObject();
                return $record;
            }
            else{
                return false;
            }
        }
        catch(PDOException $ex){
            die($ex->getMessage());
        }
        finally{
            // Libérer les ressources
            $resultat->closeCursor();
        }
    }
}

?>