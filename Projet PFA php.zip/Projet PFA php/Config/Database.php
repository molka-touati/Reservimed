<?php
/**
 * Configuration de la base de données
 */
final class Database {

    public static $HOST = "localhost";
    public static $USER = "MR";
    public static $PASSWORD = "reservimed";
    public static $DB = "reservimed_bdd";

}
?>