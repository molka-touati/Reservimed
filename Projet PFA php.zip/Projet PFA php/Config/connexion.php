<?php
/*database Connetion*/
function connexionDB(){
    try{
        $db = new PDO("mysql:host=localhost;port=3308;dbname=reservimed_bdd", "MR", "reservimed");
        $db->query("SET NAMES 'utf8'");
        return $db;
    }
    catch(PDOException $exception){
        die($exception->getMessage());
    }
}
?>