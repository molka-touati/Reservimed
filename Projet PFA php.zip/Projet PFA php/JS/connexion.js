document.addEventListener("DOMContentLoaded", function() {
    const registerButton = document.getElementById('registerButton');
    const inscriptionForm = document.getElementById('inscriptionForm');
    const inscriptionSection = document.getElementById('inscriptionSection');


    function showRegistrationForm() {
        inscriptionSection.classList.remove('hidden');
        inscriptionSection.scrollIntoView({ behavior: 'smooth' });
    }
    
    function registerUser(event) {
      event.preventDefault();
      const nom = document.getElementById('nom').value.trim();
      const prenom = document.getElementById('prenom').value.trim();
      const email = document.getElementById('emailReg').value.trim();
      const password = document.getElementById('password').value.trim();
      const confirmPassword = document.getElementById('confirmPassword').value.trim();
      const errorMessages = {}; // To store error messages for each field
  
      // Logique de validation des champs de formulaire
      if (!isValidName(nom)) {
          errorMessages.nom = 'Le nom doit contenir seulement des lettres.';
      }
  
      if (!isValidName(prenom)) {
          errorMessages.prenom = 'Le prénom doit contenir seulement des lettres.';
      }
  
      if (!isValidEmail(email)) {
          errorMessages.emailReg = 'Veuillez entrer une adresse Gmail valide.';
      }
  
      if (password.length < 6) {
          errorMessages.password = 'Le mot de passe doit contenir au moins 6 caractères.';
      }
      if (password !== confirmPassword) {
          errorMessages.confirmPassword = 'Les mots de passe ne correspondent pas.';
      }
  
      // Affichage des messages d'erreur
      displayErrors(errorMessages);
  
      // Si aucun message d'erreur, envoyer le formulaire
      if (Object.keys(errorMessages).length === 0) {
          inscriptionForm.submit();
      }
  }
  
    
    function isValidName(name) {
        return /^[a-zA-Z\s]+$/.test(name);
    }
    
    function isValidEmail(email) {
        return /\S+@\S+\.\S+/.test(email) && email.endsWith('@gmail.com');
    }
    
    function displayErrors(errors) {
      for (const fieldName in errors) {
          const errorMessageElement = document.getElementById(`${fieldName}ErrorMessage`);
          const errorMessage = errors[fieldName];
          if (errorMessageElement) {
              errorMessageElement.textContent = errorMessage ? errorMessage : '';
          } else {
              console.error(`Element d'erreur introuvable pour le champ ${fieldName}`);
          }
      }
  }
    registerButton.addEventListener('click', showRegistrationForm);
    inscriptionForm.addEventListener('submit', registerUser);
});
