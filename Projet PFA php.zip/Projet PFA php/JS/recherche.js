document.addEventListener('DOMContentLoaded', function() {
    var form = document.querySelector('.search-bar form');
    var searchInput = document.getElementById('searchInput');
    var searchResults = document.getElementById('searchResults');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêche la soumission du formulaire

        var searchTerm = searchInput.value.trim(); // Récupère le terme de recherche en enlevant les espaces vides au début et à la fin

        // Affiche le terme de recherche dans les résultats
        searchResults.innerHTML = 'Résultats de recherche pour : ' + searchTerm;
    });
});