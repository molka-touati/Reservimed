document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById('FR');
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        if (validateForm()) {
            successMessage.style.display = 'block';
            errorMessage.style.display = 'none';
           
            alert('Formulaire soumis avec succès!');
        } else {
            errorMessage.style.display = 'block';
            successMessage.style.display = 'none';
        }
    });

    function validateForm() {
        const inputs = document.querySelectorAll('.form-input');
        for (let i = 0; i < inputs.length; i++) {
            if (inputs[i].value.trim() === '') {
                return false;
            }
        }
        return true;
    }
});

