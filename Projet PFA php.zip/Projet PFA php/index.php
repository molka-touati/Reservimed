<?php
session_start();
// Déclaration des variables utiles
$ROOT = __DIR__; // Chemin complet du projet
$DS = DIRECTORY_SEPARATOR; // Séparateur utilisé selon le système d'exploitation

// Récupérer le nom du contrôlleur et l'action
if(!empty($_GET["controller"])){
    $controller = $_GET["controller"];
}
else{
    $controller = "utilisateur";
}

if(!empty($_GET["action"])){
    $action = $_GET["action"];
}
else{
    $action = "lister";
}

// Fichier à inclure
$file = $ROOT . $DS . "Controller" . $DS . ucfirst($controller) . "Controller.php";
if(file_exists($file)){
    require_once $file;
}
else{
    die("Controlleur introuvable!");
}


