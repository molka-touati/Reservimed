<?php
include_once $ROOT . $DS . "Model/userReserviMed.php"; 
switch($action){
    case "sign_in":
        $email=$_POST["email"];
        $password=$_POST["password"];
        $utilisateur = new ModelUtilisateur();
        $utilisateur = $utilisateur->getByEmail($email);
        if($utilisateur == false){
            die("Vérifier votre email ou mot de passe");
        }
        else
         require_once "userpage.php";
    break;
    case "lister_user":
		$utilisateur = new ModelUtilisateur ();
        $listeUtilisateurs = $utilisateur->getAll();
        require_once "userpage.php";
        break;
    case "lister":
		$utilisateur = new ModelUtilisateur ();
        $listeUtilisateurs = $utilisateur->getAll();
        require_once "view/userreservimed/liste.php";
        break;
    case "lister_user":
        $utilisateur = new ModelUtilisateur ();
        $listeUtilisateurs = $utilisateur->getAll();
        require_once "userpage.php";
        break;  
    case "ajout1":
        require_once "view/form_connexion.php"; 
        break;
        case "ajoutuser":
            if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"]) || empty($_REQUEST["prenom"]) || empty($_REQUEST["email"]) || empty($_REQUEST["telephone"]) || empty($_REQUEST["date_naissance"]) || empty($_REQUEST["lieuDeVie"]) || empty($_REQUEST["ville"]) || empty($_REQUEST["genre"]) || empty($_REQUEST["password"])){
                die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
            }
            // Récupérer les données du formulaire
            $CIN = $_REQUEST["cin"];
            $nomUT = $_REQUEST["nom"];
            $prenomUT = $_REQUEST["prenom"]; 
            $emailUT= $_REQUEST["email"];
            $numtel = $_REQUEST["telephone"];
            $ddn = $_REQUEST["date_naissance"];
            $villeUT = $_REQUEST["ville"];
            $gvrUT = $_REQUEST["lieuDeVie"];
            $genre = $_REQUEST["genre"];
            $mdp= $_REQUEST["password"];
            
            // Créer une instance de la classe ModelUtilisateur
            $user = new ModelUtilisateur();
            
            // Insérer les données dans la base de données
            $resultat = $user->insert([
                "CIN" => $CIN,
                "nomUT" => $nomUT,
                "prenomUT" => $prenomUT,
                "emailUT" => $emailUT,
                "numtel" => $numtel,
                "ddn" => $ddn,
                "villeUT" => $villeUT,
                "gvrUT" => $gvrUT,
                "genre" => $genre,
                "mdp" => $mdp
            ]);
            require_once "view/userreservimed/ajout1.php"; // Vue pour afficher le résultat de l'ajout
            break;
    case "ajout":
        require_once "view/userreservimed/ajout_form.php"; 
         break;
    case "ajout2":
        
        if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"]) || empty($_REQUEST["prenom"]) || empty($_REQUEST["email"]) || empty($_REQUEST["telephone"]) || empty($_REQUEST["date_naissance"]) || empty($_REQUEST["lieuDeVie"]) || empty($_REQUEST["ville"]) || empty($_REQUEST["genre"]) || empty($_REQUEST["password"])){
            die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
        }
        // Récupérer les données du formulaire
        $CIN = $_REQUEST["cin"];
        $nomUT = $_REQUEST["nom"];
        $prenomUT = $_REQUEST["prenom"]; 
        $emailUT= $_REQUEST["email"];
        $numtel = $_REQUEST["telephone"];
        $ddn = $_REQUEST["date_naissance"];
        $villeUT = $_REQUEST["ville"];
        $gvrUT = $_REQUEST["lieuDeVie"];
        $genre = $_REQUEST["genre"];
        $mdp= $_REQUEST["password"];
        
        // Créer une instance de la classe ModelUtilisateur
        $user = new ModelUtilisateur();
        
        // Insérer les données dans la base de données
        $resultat = $user->insert([
            "CIN" => $CIN,
            "nomUT" => $nomUT,
            "prenomUT" => $prenomUT,
            "emailUT" => $emailUT,
            "numtel" => $numtel,
            "ddn" => $ddn,
            "villeUT" => $villeUT,
            "gvrUT" => $gvrUT,
            "genre" => $genre,
            "mdp" => $mdp
        ]);
        require_once "view/userreservimed/ajout.php"; // Vue pour afficher le résultat de l'ajout
        break;
    case "modif":
		if(empty($_GET["cin"])){
            die("Veuillez indiquer le cin d'utilisateur");
        }
        // Récupérer l'identifiant du livre
        $CIN = (int)$_GET["cin"];
        $utilisateur = new ModelUtilisateur();
        $utilisateur = $utilisateur->getById($CIN);
        if($utilisateur == false){
            die("utilisateur introuvable!");
        }
        require_once "view/userreservimed/modif1.php";
		break;
		case "modif2":
			if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"]) || empty($_REQUEST["prenom"]) || empty($_REQUEST["email"]) || empty($_REQUEST["telephone"]) || empty($_REQUEST["date_naissance"]) || empty($_REQUEST["lieuDeVie"]) || empty($_REQUEST["ville"]) || empty($_REQUEST["genre"]) || empty($_REQUEST["password"])){
				die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
			}
			// Récupérer les données du formulaire
			$CIN = $_REQUEST["cin"];
			$nomUT = $_REQUEST["nom"];
			$prenomUT = $_REQUEST["prenom"]; 
			$emailUT= $_REQUEST["email"];
			$numtel = $_REQUEST["telephone"];
			$ddn = $_REQUEST["date_naissance"];
			$villeUT = $_REQUEST["ville"];
			$gvrUT = $_REQUEST["lieuDeVie"];
			$genre = $_REQUEST["genre"];
			$mdp= $_REQUEST["password"];

			$utilisateur = new ModelUtilisateur();
			$resultat = $utilisateur->update([
				"CIN" => $CIN,
				"nomUT" => $nomUT,
				"prenomUT" => $prenomUT,
				"emailUT" => $emailUT,
				"numtel" => $numtel,
				"ddn" => $ddn,
				"villeUT" => $villeUT,
				"gvrUT" => $gvrUT,
				"genre" => $genre,
				"mdp" => $mdp
			],$CIN);
			
			// Charger la vue appropriée
			require_once "view/userreservimed/modif2.php"; // Vue pour afficher le résultat de la modification
			break;
		case "delete":
			// Vérifier si le formulaire a bien été rempli
			if(empty($_GET["cin"])){
				die("Veuillez indiquer le cin !");
			}
			$CIN = (int)$_GET["cin"];
			$user = new ModelUtilisateur ();
			$resultat = $user->delete($CIN);
			require_once "view/userreservimed/supprimer.php";
			break;
	}
	?>
