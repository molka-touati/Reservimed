<?php
require_once $ROOT . $DS . "Model/medecin.php"; 
require_once $ROOT . $DS . "Model/rdv.php"; 
switch($action){
    case "lister":
		$rdv = new rdv ();
        $listerdv = $rdv->getAll();
        require_once "view/rdv/liste.php";
        break;
    case "ajout":
        require_once "view/Reserver.php"; 
        break;
    case "modif":
            if(empty($_GET["cin"])){
                die("Veuillez indiquer l'identifiant de medécin");
            }
            // Récupérer l'identifiant du livre
            $CIN = (int)$_GET["cin"];
            $rdv = new rdv ();
            $rdv = $rdv->getById($CIN);
            if($rdv == false){
                die("rendez_vous introuvable!");
            }
            require_once "view/rdv/modif1.php";
            break;
        case "modif2":
                if(empty($_REQUEST["nom"]) || empty($_REQUEST["prenom"]) || empty($_REQUEST["email"]) || empty($_REQUEST["numero"]) || empty($_REQUEST["date"]) || empty($_REQUEST["heure"]) ||  empty($_REQUEST["cin"])){
                    die("Veuillez remplir tous les champs!");
                }
                $CIN = $_REQUEST["cin"];
                $Nom = $_REQUEST["nom"];
                $Prenom = $_REQUEST["prenom"]; 
                $Email= $_REQUEST["email"];
                $Numtel = $_REQUEST["numero"];
                $dateRDV = $_REQUEST["date"];
                $heureRDV = $_REQUEST["heure"];
                $rdv = new rdv();
                $resultat = $rdv->update([
                    "CIN" => $CIN,
                    "Nom" => $Nom,
                    "Prenom" => $Prenom,
                    "Email" => $Email,
                    "Numtel" => $Numtel,
                    "dateRDV" => $dateRDV,
                    "heureRDV" => $heureRDV,
                ]);
                require_once "view/rdv/modif2.php"; // Vue pour afficher le résultat de la modification
                break;
    case "ajout2":
        if(empty($_REQUEST["nom"]) || empty($_REQUEST["prenom"]) || empty($_REQUEST["email"]) || empty($_REQUEST["numero"]) || empty($_REQUEST["date"]) || empty($_REQUEST["heure"]) ||  empty($_REQUEST["cin"])){
            die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
        }
        $CIN = $_REQUEST["cin"];
        $Nom = $_REQUEST["nom"];
        $Prenom = $_REQUEST["prenom"]; 
        $Email= $_REQUEST["email"];
        $Numtel = $_REQUEST["numero"];
        $dateRDV = $_REQUEST["date"];
        $heureRDV = $_REQUEST["heure"];
        $IDMD=$_GET["medecin"];
        // Créer une instance de la classe ModelUtilisateur
        $rdv = new rdv();
        
        // Insérer les données dans la base de données
        $resultat = $rdv->insert([
            "CIN" => $CIN,
            "Nom" => $Nom,
            "Prenom" => $Prenom,
            "Email" => $Email,
            "Numtel" => $Numtel,
            "dateRDV" => $dateRDV,
            "heureRDV" => $heureRDV,
            "IDMD" =>  $IDMD,
        ]);
        require_once "view/rdv/ajout.php"; // Vue pour afficher le résultat de l'ajout
        break;
		case "delete":
			// Vérifier si le formulaire a bien été rempli
			if(empty($_GET["cin"])){
				die("Veuillez indiquer le cin !");
			}
			$CIN = (int)$_GET["cin"];
			$rdv = new rdv ();
			$resultat = $rdv->delete($CIN);
			require_once "view/rdv/supprimer.php";
			break;
	}
	?>
