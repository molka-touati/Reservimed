<?php
require_once $ROOT . $DS . "Model/commentaire.php"; 
switch($action){
    case "lister":
		$cmnt = new commentaire ();
        $listecmnts = $cmnt->getAll();
        require_once "view/commentaire/liste.php";
        break;
    case "ajout":
        require_once "accueil.php"; 
        break;
    case "ajout2":
        
        if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"]) || empty($_REQUEST["commentaire"])){
            die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
        }
        $CIN = $_REQUEST["cin"];
        $Nom = $_REQUEST["nom"];
        $Cmnt = $_REQUEST["commentaire"];
        
        // Créer une instance de la classe ModelUtilisateur
        $cmnt = new commentaire();
        
        // Insérer les données dans la base de données
        $resultat = $cmnt->insert([
            "CIN" => $CIN,
            "Nom" => $Nom,
            "Cmnt" => $Cmnt,
        ]);
        require_once "view/commentaire/ajout.php"; // Vue pour afficher le résultat de l'ajout
        break;
		case "delete":
            $CIN = $_REQUEST["cin"];
			$cmnt = new commentaire ();
			$resultat = $cmnt->delete($CIN);
			require_once "view/commentaire/supprimer.php";
			break;
	}
	?>
