<?php
require_once $ROOT . $DS . "Model/admin.php"; 
switch($action){
	case "sign_in":
        $email=$_POST["email"];
        $password=$_POST["password"];
        $admin = new administrateur ();
		$admin =  $admin->getByEmail($email);
        if( $admin == false){
            die("Vérifier votre email ou mot de passe");
        }
        else
         require_once "view/admin/liste1.php";
    case "lister":
		$admin = new administrateur ();
        $listeadmin = $admin->getAll();
        require_once "view/admin/liste.php";
        break;
    case "ajout":
        require_once "view/admin/ajout_form.php"; 
        break;
    case "ajout2":
        if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"])  || empty($_REQUEST["email"])  || empty($_REQUEST["mdp"])){
            die("Veuillez remplir tous les champs!");
        }
        $CIN = $_REQUEST["cin"];
        $Nom = $_REQUEST["nom"];
		$Email = $_REQUEST["email"];
		$Password = $_REQUEST["mdp"];
        $admin = new administrateur();
        $resultat = $med->insert([
            "CIN" => $CIN,
            "Nom" => $Nom,
			"Email" => $Email,
			"Password" => $Password,
        ],$CIN);
        require_once "view/admin/ajout.php";
        break;
    case "modif":
		if(empty($_GET["cin"])){
            die("Veuillez indiquer le CIN de l'admin ");
        }
        $CIN = (int)$_GET["cin"];
        $admin = new administrateur();
        $admin = $admin->getById($CIN);
        if($admin == false){
            die("admin introuvable!");
        }
        require_once "view/admin/modif1.php";
		break;
		case "modif2":
			if(empty($_REQUEST["cin"]) || empty($_REQUEST["nom"])  || empty($_REQUEST["email"])  || empty($_REQUEST["mdp"])){
				die("Veuillez remplir tous les champs!");
			}
			$CIN = $_REQUEST["cin"];
			$Nom = $_REQUEST["nom"];
			$Email = $_REQUEST["email"];
			$Password = $_REQUEST["mdp"];
			$admin = new administrateur();
			$resultat = $admin->update([
				"CIN" => $CIN,
				"Nom" => $Nom,
				"Email" => $Email,
				"Password" => $Password,
			],$CIN);
			require_once "view/admin/modif2.php";
			break;
			case "delete":
				if(empty($_GET["cin"])){
					die("Veuillez indiquer le CIN!");
				}
				$CIN = (int)$_GET["cin"];
				$admin = new administrateur ();
				$resultat = $admin->delete($CIN);
				require_once "view/admin/supprimer.php";
				break;
		}
		?>