<?php
require_once $ROOT . $DS . "Model/medecin.php"; 
switch($action){
    case "lister":
		$med = new medecin ();
        $listemedecin = $med->getAll();
        require_once "view/medecin/liste.php";
        break;
    case "lister_user":
        $med = new medecin ();
        $listemedecin = $med->getAll();
        require_once "view/ListeMed.php";
        break;
    case "ajout":
        require_once "view/medecin/ajout_form.php"; 
        break;
    case "ajout2":
        
        if(empty($_REQUEST["id"]) || empty($_REQUEST["nommed"]) || empty($_REQUEST["prenommed"]) || empty($_REQUEST["emailmed"]) || empty($_REQUEST["telephonemed"]) || empty($_REQUEST["specmed"]) || empty($_REQUEST["localmed"]) || empty($_REQUEST["lieuDeVie"]) || empty($_REQUEST["fbmed"]) || empty($_REQUEST["instamed"]) || empty($_REQUEST["datedispo"])||empty($_REQUEST["heuredispo"])){
            die("Veuillez remplir tous les champs!"); // Arrêter l'exécution si des champs sont manquants
        }
        // Récupérer les données du formulaire
        $IDMD = $_REQUEST["id"];
        $nomMD = $_REQUEST["nommed"];
        $prenomMD = $_REQUEST["prenommed"]; 
        $emailMD= $_REQUEST["emailmed"];
        $numtelMD = $_REQUEST["telephonemed"];
        $specMD = $_REQUEST["specmed"];
        $gvrMD = $_REQUEST["lieuDeVie"];
        $localMD = $_REQUEST["localmed"];
        $fbMD = $_REQUEST["fbmed"];
        $instaMD= $_REQUEST["instamed"];
		$dispoMD= $_REQUEST["datedispo"];
        $heureDispoMD=$_REQUEST["heuredispo"];
        
        // Créer une instance de la classe ModelUtilisateur
        $med = new medecin();
        
        // Insérer les données dans la base de données
        $resultat = $med->insert([
            "IDMD" => $IDMD,
            "nomMD" => $nomMD,
            "prenomMD" => $prenomMD,
            "emailMD" => $emailMD,
            "numtelMD" => $numtelMD,
            "specMD" => $specMD,
            "gvrMD" => $gvrMD,
            "localMD" => $localMD,
            "fbMD" => $fbMD,
            "instaMD" => $instaMD,
			"dispoMD" => $dispoMD,
            "heureDispoMD" => $heureDispoMD,
        ],$IDMD);
        require_once "view/userreservimed/ajout.php"; // Vue pour afficher le résultat de l'ajout
        break;
    case "modif":
		if(empty($_GET["id"])){
            die("Veuillez indiquer l'identifiant de medécin");
        }
        // Récupérer l'identifiant du livre
        $IDMD = (int)$_GET["id"];
        $med = new medecin();
        $med = $med->getById($IDMD);
        if($med == false){
            die("medecin introuvable!");
        }
        require_once "view/medecin/modif1.php";
		break;
		case "modif2":
			if(empty($_REQUEST["id"]) || empty($_REQUEST["nommed"]) || empty($_REQUEST["prenommed"]) || empty($_REQUEST["emailmed"]) || empty($_REQUEST["telephonemed"]) || empty($_REQUEST["specmed"]) || empty($_REQUEST["localmed"]) || empty($_REQUEST["lieuDeVie"]) || empty($_REQUEST["fbmed"]) || empty($_REQUEST["instamed"]) || empty($_REQUEST["datedispo"])){
				die("Veuillez remplir tous les champs!"); 
			}
			// Récupérer les données du formulaire
			$IDMD = $_REQUEST["id"];
			$nomMD = $_REQUEST["nommed"];
			$prenomMD = $_REQUEST["prenommed"]; 
			$emailMD= $_REQUEST["emailmed"];
			$numtelMD = $_REQUEST["telephonemed"];
			$specMD = $_REQUEST["specmed"];
			$gvrMD = $_REQUEST["lieuDeVie"];
			$localMD = $_REQUEST["localmed"];
			$fbMD = $_REQUEST["fbmed"];
			$instaMD= $_REQUEST["instamed"];
			$dispoMD= $_REQUEST["datedispo"];
			$heureDispoMD=$_REQUEST["heuredispo"];

			$med = new medecin();
			$resultat = $med->update([
				"IDMD" => $IDMD,
				"nomMD" => $nomMD,
				"prenomMD" => $prenomMD,
				"emailMD" => $emailMD,
				"numtelMD" => $numtelMD,
				"specMD" => $specMD,
				"gvrMD" => $gvrMD,
				"localMD" => $localMD,
				"fbMD" => $fbMD,
				"instaMD" => $instaMD,
				"dispoMD" => $dispoMD,
                "heureDispoMD" => $heureDispoMD,
			],$IDMD);
			
			// Charger la vue appropriée
			require_once "view/medecin/modif2.php"; // Vue pour afficher le résultat de la modification
			break;
		case "delete":
			// Vérifier si le formulaire a bien été rempli
			if(empty($_GET["IDMD"])){
				die("Veuillez indiquer l'identifiant !");
			}
			$IDMD = (int)$_GET["IDMD"];
			$med = new medecin ();
			$resultat = $med->delete($IDMD);
			require_once "view/medecin/supprimer.php";
			break;
	}
	?>
